import os
import json
import logging
import time
import re
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ConversationHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")
if not TOKEN:
    raise ValueError("❌ Token bot tidak ditemukan di .env")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
JSON_PATH = os.path.join(BASE_DIR, "gym_data.json")
IMAGE_DIR = os.path.join(BASE_DIR, "images")
os.makedirs(IMAGE_DIR, exist_ok=True)

# Load data
try:
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        GYM_DATA = json.load(f)
    for gym in GYM_DATA:
        gym.setdefault("status", "approved")
        gym.setdefault("gambar", "")
        gym.setdefault("hp_wa", "")
        gym.setdefault("medsos", "")
        gym.setdefault("link_maps", "")
        gym.setdefault("link_drive", "")
    logger.info(f"✅ Data gym dimuat: {len(GYM_DATA)} item")
except:
    GYM_DATA = []
    logger.warning("⚠️ File gym_data.json tidak ditemukan, memulai kosong.")

def save_gym_data():
    with open(JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(GYM_DATA, f, indent=2, ensure_ascii=False)

def get_image_path(filename):
    return os.path.join(IMAGE_DIR, filename)

def is_admin(user_id):
    return user_id == ADMIN_ID

def escape_markdown(text):
    if not isinstance(text, str):
        return text
    escape_chars = r'_*[]()~`>#+-=|{}.!'
    return re.sub(f'([{re.escape(escape_chars)}])', r'\\\1', text)

user_sessions = {}
upload_temp = {}

async def delete_message_safe(context, chat_id, message_id):
    try:
        await context.bot.delete_message(chat_id=chat_id, message_id=message_id)
    except Exception as e:
        logger.warning(f"Gagal hapus pesan: {e}")

async def safe_answer(query, text=None, show_alert=False):
    try:
        await query.answer(text, show_alert=show_alert)
    except:
        pass

def build_gym_caption(gym, index, total):
    caption = (
        f"🏋️ *{escape_markdown(gym['nama'])}*\n\n"
        f"📍 Lokasi: {escape_markdown(gym['lokasi'])}\n"
        f"📞 HP/WA: {escape_markdown(gym['hp_wa'])}\n"
        f"🌐 Medsos: {escape_markdown(gym['medsos'])}\n"
        f"🗺️ [Google Maps]({gym['link_maps']})\n"
        f"📁 [Drive]({gym['link_drive']})\n\n"
        f"Gym {index+1} dari {total}"
    )
    return caption

def build_detail_keyboard(index, total, gym):
    buttons = []
    nav_row = []
    if index > 0:
        nav_row.append(InlineKeyboardButton("◀️ Sebelumnya", callback_data="nav_prev"))
    nav_row.append(InlineKeyboardButton("❌ Tutup", callback_data="nav_close"))
    if index < total - 1:
        nav_row.append(InlineKeyboardButton("▶️ Berikutnya", callback_data="nav_next"))
    buttons.append(nav_row)

    if gym.get("hp_wa"):
        wa_link = f"https://wa.me/{gym['hp_wa']}"
        buttons.append([InlineKeyboardButton("📞 Hubungi Admin", url=wa_link)])
    else:
        buttons.append([InlineKeyboardButton("📞 Hubungi Admin", callback_data="no_contact")])
    if gym.get("medsos"):
        medsos = gym['medsos']
        if not medsos.startswith("http"):
            medsos = "https://" + medsos
        buttons.append([InlineKeyboardButton("🌐 Medsos", url=medsos)])
    else:
        buttons.append([InlineKeyboardButton("🌐 Medsos", callback_data="no_medsos")])

    buttons.append([InlineKeyboardButton("⭐ Rating Gym", callback_data=f"rate_{gym['id']}")])
    buttons.append([InlineKeyboardButton("🔙 Kembali ke Daftar", callback_data="back_to_list")])
    return InlineKeyboardMarkup(buttons)

# ==================== MENU UTAMA ====================
async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("🔍 Cari Gym", callback_data="menu_cari")],
        [InlineKeyboardButton("📤 Upload Gym Baru", callback_data="menu_upload")],
    ]
    if is_admin(update.effective_user.id):
        keyboard.append([InlineKeyboardButton("⚙️ Admin Panel", callback_data="admin_panel")])
    reply = InlineKeyboardMarkup(keyboard)
    text = "🏠 **Menu Utama**\nPilih menu:"

    if update.message:
        welcome_path = get_image_path("welcome.jpg")
        if os.path.exists(welcome_path):
            with open(welcome_path, "rb") as photo:
                await update.message.reply_photo(
                    photo=photo,
                    caption="👋 *Selamat datang di GYM BOT!*\n\n" + text,
                    reply_markup=reply,
                    parse_mode="Markdown"
                )
        else:
            await update.message.reply_text(text, reply_markup=reply, parse_mode="Markdown")
    else:
        query = update.callback_query
        if query.message:
            await delete_message_safe(context, query.message.chat_id, query.message.message_id)
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=text,
            reply_markup=reply,
            parse_mode="Markdown"
        )

# ==================== CARI GYM ====================
async def menu_cari(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    lokasi_set = sorted({g["lokasi"] for g in GYM_DATA if g.get("status") == "approved" and g.get("lokasi")})
    if not lokasi_set:
        keyboard = [[InlineKeyboardButton("🔙 Kembali", callback_data="main")]]
        reply = InlineKeyboardMarkup(keyboard)
        if query.message:
            await delete_message_safe(context, query.message.chat_id, query.message.message_id)
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="❌ Belum ada gym yang disetujui.",
            reply_markup=reply
        )
        return

    keyboard = [[InlineKeyboardButton(loc.title(), callback_data=f"wilayah_{loc}")] for loc in lokasi_set]
    keyboard.append([InlineKeyboardButton("🔙 Kembali", callback_data="main")])
    reply = InlineKeyboardMarkup(keyboard)
    if query.message:
        await delete_message_safe(context, query.message.chat_id, query.message.message_id)
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="📍 **Pilih Wilayah Gym**",
        reply_markup=reply,
        parse_mode="Markdown"
    )

async def pilih_wilayah(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    wilayah = query.data.split("_", 1)[1]
    results = [g for g in GYM_DATA if g["lokasi"].lower() == wilayah.lower() and g.get("status") == "approved"]
    if not results:
        await safe_answer(query, "Tidak ada gym di wilayah ini.", show_alert=True)
        return
    user_id = update.effective_user.id
    user_sessions[user_id] = {"list": results, "index": 0}
    await tampilkan_gym(update, context, user_id)

async def tampilkan_gym(update, context, user_id):
    session = user_sessions.get(user_id)
    if not session:
        return
    index = session["index"]
    gym = session["list"][index]
    caption = build_gym_caption(gym, index, len(session["list"]))
    reply = build_detail_keyboard(index, len(session["list"]), gym)

    query = update.callback_query
    if query.message:
        await delete_message_safe(context, query.message.chat_id, query.message.message_id)

    image_path = get_image_path(gym.get("gambar", ""))
    if os.path.exists(image_path):
        with open(image_path, "rb") as photo:
            sent = await context.bot.send_photo(
                chat_id=update.effective_chat.id,
                photo=photo,
                caption=caption,
                reply_markup=reply,
                parse_mode="Markdown"
            )
    else:
        sent = await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=f"{caption}\n\n⚠️ Gambar tidak tersedia",
            reply_markup=reply,
            parse_mode="Markdown"
        )
    session["message_id"] = sent.message_id
    await safe_answer(query)

async def nav_slide(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    user_id = update.effective_user.id
    session = user_sessions.get(user_id)
    if not session:
        await safe_answer(query, "Sesi habis. /start kembali.", show_alert=True)
        return

    if data == "nav_close":
        await delete_message_safe(context, query.message.chat_id, session["message_id"])
        user_sessions.pop(user_id, None)
        await safe_answer(query, "Ditutup.")
        await show_main_menu(update, context)
        return

    if data == "nav_prev":
        session["index"] -= 1
    elif data == "nav_next":
        session["index"] += 1
    else:
        return

    if session["index"] < 0 or session["index"] >= len(session["list"]):
        session["index"] = max(0, min(session["index"], len(session["list"])-1))
        await safe_answer(query, "Sudah di ujung daftar.", show_alert=True)
        return

    await tampilkan_gym(update, context, user_id)

async def back_to_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = update.effective_user.id
    session = user_sessions.get(user_id)
    if session:
        await menu_cari(update, context)
    else:
        await show_main_menu(update, context)

# ==================== RATING ====================
async def rating_from_detail(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    gym_id = int(query.data.split("_")[1])
    context.user_data['rating_gym_id'] = gym_id
    keyboard = [
        [InlineKeyboardButton("1", callback_data="rate_1"),
         InlineKeyboardButton("2", callback_data="rate_2"),
         InlineKeyboardButton("3", callback_data="rate_3"),
         InlineKeyboardButton("4", callback_data="rate_4"),
         InlineKeyboardButton("5", callback_data="rate_5")],
        [InlineKeyboardButton("🔙 Batal", callback_data="cancel_rating")]
    ]
    reply = InlineKeyboardMarkup(keyboard)
    await query.edit_message_text(
        text="⭐ **Berikan Rating untuk gym ini**\nPilih angka 1–5:",
        reply_markup=reply,
        parse_mode="Markdown"
    )
    await safe_answer(query)

async def proses_rating(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    rating = query.data.split("_")[1]
    await safe_answer(query, f"Terima kasih! Rating {rating} telah disimpan.")
    user_id = update.effective_user.id
    session = user_sessions.get(user_id)
    if session:
        await tampilkan_gym(update, context, user_id)
    else:
        await show_main_menu(update, context)

async def cancel_rating(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await safe_answer(query, "Rating dibatalkan.")
    user_id = update.effective_user.id
    session = user_sessions.get(user_id)
    if session:
        await tampilkan_gym(update, context, user_id)
    else:
        await show_main_menu(update, context)

# ==================== UPLOAD GYM ====================
UPLOAD_NAME, UPLOAD_LOCATION, UPLOAD_HP, UPLOAD_MEDSOS, UPLOAD_MAPS, UPLOAD_DRIVE, UPLOAD_PHOTO, UPLOAD_CONFIRM = range(20, 28)

async def menu_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await safe_answer(query)
    user_id = update.effective_user.id
    upload_temp[user_id] = {}
    if query.message:
        await delete_message_safe(context, query.message.chat_id, query.message.message_id)
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="📤 **Upload Gym Baru**\n\nKirim *nama gym*:",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Batal", callback_data="cancel_upload")]]),
        parse_mode="Markdown"
    )
    return UPLOAD_NAME

async def upload_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    upload_temp[user_id]["nama"] = update.message.text
    # Tampilkan tombol pilihan lokasi
    lokasi_set = sorted({g["lokasi"] for g in GYM_DATA if g.get("lokasi")})
    if not lokasi_set:
        lokasi_set = ["Klojen", "Blimbing", "Lowokwaru"]
    buttons = [[InlineKeyboardButton(loc, callback_data=f"uploc_{loc}")] for loc in lokasi_set]
    buttons.append([InlineKeyboardButton("➕ Lainnya", callback_data="uploc_manual")])
    buttons.append([InlineKeyboardButton("❌ Batal", callback_data="cancel_upload")])
    reply = InlineKeyboardMarkup(buttons)
    await update.message.reply_text(
        "📍 Pilih *lokasi* gym dari tombol di bawah, atau pilih 'Lainnya' untuk mengetik manual:",
        reply_markup=reply,
        parse_mode="Markdown"
    )
    return UPLOAD_LOCATION

async def upload_location_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    user_id = update.effective_user.id
    await safe_answer(query)
    if user_id not in upload_temp:
        await query.edit_message_text("Sesi upload habis. Mulai ulang.")
        return ConversationHandler.END

    if data == "uploc_manual":
        await query.edit_message_text(
            "📍 Masukkan *lokasi* secara manual (contoh: Klojen):",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Batal", callback_data="cancel_upload")]]),
            parse_mode="Markdown"
        )
        return UPLOAD_LOCATION
    else:
        lokasi = data.split("_", 1)[1]
        upload_temp[user_id]["lokasi"] = lokasi
        await query.edit_message_text(
            f"✅ Lokasi: {lokasi}\n\n📞 Kirim *nomor HP/WA* (contoh: 081234567890):",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Batal", callback_data="cancel_upload")]]),
            parse_mode="Markdown"
        )
        return UPLOAD_HP

async def receive_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    upload_temp[user_id]["lokasi"] = update.message.text
    await update.message.reply_text(
        "📞 Kirim *nomor HP/WA* (contoh: 081234567890):",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Batal", callback_data="cancel_upload")]]),
        parse_mode="Markdown"
    )
    return UPLOAD_HP

async def upload_hp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    upload_temp[user_id]["hp_wa"] = update.message.text
    await update.message.reply_text(
        "🌐 Kirim *medsos* (contoh: @gymcenter atau link):",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Batal", callback_data="cancel_upload")]]),
        parse_mode="Markdown"
    )
    return UPLOAD_MEDSOS

async def upload_medsos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    upload_temp[user_id]["medsos"] = update.message.text
    await update.message.reply_text(
        "🗺️ Kirim *link Google Maps*:",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Batal", callback_data="cancel_upload")]]),
        parse_mode="Markdown"
    )
    return UPLOAD_MAPS

async def upload_maps(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    upload_temp[user_id]["link_maps"] = update.message.text
    await update.message.reply_text(
        "📁 Kirim *link Drive* (foto tambahan):",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Batal", callback_data="cancel_upload")]]),
        parse_mode="Markdown"
    )
    return UPLOAD_DRIVE

async def upload_drive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    upload_temp[user_id]["link_drive"] = update.message.text
    await update.message.reply_text(
        "🖼️ Kirim *foto utama* gym (kirim gambar):",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Batal", callback_data="cancel_upload")]]),
        parse_mode="Markdown"
    )
    return UPLOAD_PHOTO

async def upload_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    photo_file = update.message.photo[-1]
    file = await context.bot.get_file(photo_file.file_id)
    timestamp = int(time.time())
    filename = f"upload_{user_id}_{timestamp}.jpg"
    filepath = get_image_path(filename)
    await file.download_to_drive(filepath)
    upload_temp[user_id]["gambar"] = filename

    data = upload_temp[user_id]
    caption = (
        f"📋 *Konfirmasi Data Gym*\n\n"
        f"📌 Nama: {escape_markdown(data['nama'])}\n"
        f"📍 Lokasi: {escape_markdown(data['lokasi'])}\n"
        f"📞 HP/WA: {escape_markdown(data['hp_wa'])}\n"
        f"🌐 Medsos: {escape_markdown(data['medsos'])}\n"
        f"🗺️ Maps: {data['link_maps']}\n"
        f"📁 Drive: {data['link_drive']}\n\n"
        f"⚠️ *Gym akan masuk verifikasi admin.*\nApakah data sudah benar?"
    )
    keyboard = [
        [InlineKeyboardButton("✅ Simpan", callback_data="confirm_yes"),
         InlineKeyboardButton("❌ Batal", callback_data="confirm_no")]
    ]
    reply = InlineKeyboardMarkup(keyboard)
    try:
        with open(filepath, "rb") as photo:
            await update.message.reply_photo(
                photo=photo,
                caption=caption,
                reply_markup=reply,
                parse_mode="Markdown"
            )
    except Exception as e:
        logger.warning(f"Gagal kirim foto konfirmasi: {e}")
        await update.message.reply_text(
            caption + "\n\n⚠️ Gambar tidak dapat ditampilkan.",
            reply_markup=reply,
            parse_mode="Markdown"
        )
    return UPLOAD_CONFIRM

async def confirm_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await safe_answer(query)
    user_id = update.effective_user.id
    data = upload_temp.get(user_id)
    if not data:
        await query.edit_message_text("⚠️ Data tidak ditemukan.")
        return ConversationHandler.END

    if query.data == "confirm_yes":
        new_id = max([g["id"] for g in GYM_DATA], default=0) + 1
        gym_baru = {
            "id": new_id,
            "nama": data["nama"],
            "lokasi": data["lokasi"],
            "hp_wa": data["hp_wa"],
            "medsos": data["medsos"],
            "link_maps": data["link_maps"],
            "link_drive": data["link_drive"],
            "gambar": data["gambar"],
            "status": "pending"
        }
        GYM_DATA.append(gym_baru)
        save_gym_data()
        await delete_message_safe(context, query.message.chat_id, query.message.message_id)
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="✅ **Gym berhasil diupload dan menunggu verifikasi admin.**",
            parse_mode="Markdown"
        )
        if ADMIN_ID:
            try:
                await context.bot.send_message(
                    chat_id=ADMIN_ID,
                    text=f"🆕 *Gym Baru Pending*\nNama: {gym_baru['nama']}\nLokasi: {gym_baru['lokasi']}\nID: {new_id}",
                    parse_mode="Markdown"
                )
            except:
                pass
    else:
        if os.path.exists(get_image_path(data.get("gambar", ""))):
            os.remove(get_image_path(data["gambar"]))
        await delete_message_safe(context, query.message.chat_id, query.message.message_id)
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="❌ Upload dibatalkan."
        )

    upload_temp.pop(user_id, None)
    await show_main_menu(update, context)
    return ConversationHandler.END

async def cancel_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    data = upload_temp.pop(user_id, None)
    if data and os.path.exists(get_image_path(data.get("gambar", ""))):
        os.remove(get_image_path(data["gambar"]))
    await update.message.reply_text("❌ Upload dibatalkan.")
    await show_main_menu(update, context)
    return ConversationHandler.END

async def cancel_upload_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await safe_answer(query)
    user_id = update.effective_user.id
    data = upload_temp.pop(user_id, None)
    if data and os.path.exists(get_image_path(data.get("gambar", ""))):
        os.remove(get_image_path(data["gambar"]))
    if query.message:
        await delete_message_safe(context, query.message.chat_id, query.message.message_id)
    await show_main_menu(update, context)
    return ConversationHandler.END

# ==================== ADMIN PANEL ====================
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await safe_answer(update.callback_query, "Anda bukan admin.", show_alert=True)
        return
    query = update.callback_query
    pending = [g for g in GYM_DATA if g.get("status") == "pending"]
    if query.message:
        await delete_message_safe(context, query.message.chat_id, query.message.message_id)
    if not pending:
        keyboard = [[InlineKeyboardButton("🔙 Kembali", callback_data="main")]]
        reply = InlineKeyboardMarkup(keyboard)
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="✅ Tidak ada gym pending.",
            reply_markup=reply
        )
        return
    keyboard = []
    for gym in pending:
        label = f"⏳ {gym['nama']} - {gym['lokasi']}"
        keyboard.append([InlineKeyboardButton(label, callback_data=f"admin_detail_{gym['id']}")])
    keyboard.append([InlineKeyboardButton("🔙 Kembali", callback_data="main")])
    reply = InlineKeyboardMarkup(keyboard)
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="📋 **Daftar Gym Pending**",
        reply_markup=reply,
        parse_mode="Markdown"
    )

async def admin_detail(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    query = update.callback_query
    gym_id = int(query.data.split("_")[2])
    gym = next((g for g in GYM_DATA if g["id"] == gym_id), None)
    if not gym:
        await safe_answer(query, "Tidak ditemukan.", show_alert=True)
        return
    caption = (
        f"📌 *{escape_markdown(gym['nama'])}*\n"
        f"📍 {escape_markdown(gym['lokasi'])}\n"
        f"📞 {escape_markdown(gym['hp_wa'])}\n"
        f"🌐 {escape_markdown(gym['medsos'])}\n"
        f"🗺️ {gym['link_maps']}\n"
        f"📁 {gym['link_drive']}\n"
        f"🆔 ID: {gym['id']}"
    )
    keyboard = [
        [InlineKeyboardButton("✅ Setujui", callback_data=f"approve_{gym_id}"),
         InlineKeyboardButton("❌ Tolak", callback_data=f"reject_{gym_id}")],
        [InlineKeyboardButton("🔙 Kembali", callback_data="admin_panel")]
    ]
    reply = InlineKeyboardMarkup(keyboard)
    if query.message:
        await delete_message_safe(context, query.message.chat_id, query.message.message_id)
    image_path = get_image_path(gym.get("gambar", ""))
    if os.path.exists(image_path):
        with open(image_path, "rb") as photo:
            await context.bot.send_photo(
                chat_id=update.effective_chat.id,
                photo=photo,
                caption=caption,
                reply_markup=reply,
                parse_mode="Markdown"
            )
    else:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=caption,
            reply_markup=reply,
            parse_mode="Markdown"
        )

async def approve_gym(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    query = update.callback_query
    gym_id = int(query.data.split("_")[1])
    gym = next((g for g in GYM_DATA if g["id"] == gym_id), None)
    if gym:
        gym["status"] = "approved"
        save_gym_data()
        await safe_answer(query, "✅ Gym disetujui.")
    await admin_panel(update, context)

async def reject_gym(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    query = update.callback_query
    gym_id = int(query.data.split("_")[1])
    gym = next((g for g in GYM_DATA if g["id"] == gym_id), None)
    if gym:
        GYM_DATA.remove(gym)
        save_gym_data()
        image_path = get_image_path(gym.get("gambar", ""))
        if os.path.exists(image_path):
            os.remove(image_path)
        await safe_answer(query, "❌ Gym ditolak dan dihapus.")
    await admin_panel(update, context)

# ==================== ROUTER ====================
async def callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    await safe_answer(query)

    if data == "main":
        await show_main_menu(update, context)
    elif data == "menu_cari":
        await menu_cari(update, context)
    elif data == "menu_upload":
        await menu_upload(update, context)
        return
    elif data == "admin_panel":
        await admin_panel(update, context)
    elif data.startswith("wilayah_"):
        await pilih_wilayah(update, context)
    elif data.startswith("nav_"):
        await nav_slide(update, context)
    elif data == "back_to_list":
        await back_to_list(update, context)
    elif data.startswith("admin_detail_"):
        await admin_detail(update, context)
    elif data.startswith("approve_"):
        await approve_gym(update, context)
    elif data.startswith("reject_"):
        await reject_gym(update, context)
    elif data.startswith("rate_"):
        if len(data.split("_")) == 2 and data.split("_")[1].isdigit():
            await proses_rating(update, context)
        else:
            await rating_from_detail(update, context)
    elif data == "cancel_rating":
        await cancel_rating(update, context)
    elif data.startswith("uploc_"):
        # Biarkan ConversationHandler yang menangani
        pass
    elif data == "cancel_upload":
        # ConversationHandler juga menangani, tapi kita tangani di sini juga
        await cancel_upload_callback(update, context)
        return
    else:
        await show_main_menu(update, context)

# ==================== MAIN ====================
def main():
    app = (
        Application.builder()
        .token(TOKEN)
        .connect_timeout(30.0)
        .read_timeout(30.0)
        .build()
    )

    upload_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(menu_upload, pattern="^menu_upload$")],
        states={
            UPLOAD_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, upload_name)],
            UPLOAD_LOCATION: [
                CallbackQueryHandler(upload_location_callback, pattern="^uploc_"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_location)
            ],
            UPLOAD_HP: [MessageHandler(filters.TEXT & ~filters.COMMAND, upload_hp)],
            UPLOAD_MEDSOS: [MessageHandler(filters.TEXT & ~filters.COMMAND, upload_medsos)],
            UPLOAD_MAPS: [MessageHandler(filters.TEXT & ~filters.COMMAND, upload_maps)],
            UPLOAD_DRIVE: [MessageHandler(filters.TEXT & ~filters.COMMAND, upload_drive)],
            UPLOAD_PHOTO: [MessageHandler(filters.PHOTO, upload_photo)],
            UPLOAD_CONFIRM: [CallbackQueryHandler(confirm_upload, pattern="^confirm_")]
        },
        fallbacks=[CommandHandler("cancel", cancel_upload)],
    )

    app.add_handler(CommandHandler("start", show_main_menu))
    app.add_handler(upload_conv)
    app.add_handler(CallbackQueryHandler(callback_router))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, lambda u,c: None))

    logger.info("🤖 Gym Bot berjalan (menu utama 2 tombol, upload dengan tombol lokasi)...")
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)

if __name__ == "__main__":
    main()